package com.samm.workout_analyzer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkoutAnalyzerApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkoutAnalyzerApplication.class, args);
	}

}
